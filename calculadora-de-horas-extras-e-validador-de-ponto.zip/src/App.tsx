import React, { useState, useMemo } from 'react';
import { 
  FileCode, 
  HelpCircle, 
  Calculator, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  Copy, 
  Check, 
  Download, 
  Play, 
  Clock, 
  DollarSign, 
  Settings, 
  ChevronRight,
  Sparkles,
  ArrowRight,
  Info,
  AlertCircle,
  Eye,
  Plus,
  X,
  Trash2
} from 'lucide-react';
import * as XLSX from 'xlsx';

// Python script updated code template
const generatePythonCode = (
  toleranceMinutes: number = 19,
  startRow: number = 3,
  includeExcessOnly: boolean = false,
  apply100Percent: boolean = false
) => {
  return `# -----------------------------------------------------------------------------
# RELATÓRIO DE HORAS EXTRAS (XLSX com abas, colunas fixas U/V/W/X)
# - Linha 1 (Excel): cabeçalhos ExU50 | ExS100 | ExD100 | ExF100
# - Linha 2 (Excel): linha de resumo do sistema (Totais >>>) -> IGNORADA
# - Linha 3 (Excel) em diante: registros diários individuais (ex: 01/09 até 23/09)
# - REGRA DOS 19 MINUTOS (Regra Geral):
#   * Extras de 50% (coluna U - ExU50) só entram se no dia o total for > ${toleranceMinutes} minutos.
#   * Dias com <= ${toleranceMinutes} minutos (ex: 15 min, 19 min) são DESCARTADOS do cálculo total.
#   * Modo de cálculo: ${includeExcessOnly ? 'Apenas o excedente acima de ' + toleranceMinutes + ' min' : 'INTEGRAL (padrão CLT) - computa os minutos totais do dia quando ultrapassar ' + toleranceMinutes + ' min'}.
# - ABA "EXCESSÃO EXTRA" EM salarios.xlsx (EXCEÇÃO):
#   * Contém nomes de funcionários em A1:A.
#   * Para estes colaboradores, NÃO se aplica a carência de ${toleranceMinutes} minutos:
#     calcula-se CADA MINUTO trabalhado normalmente (100% dos minutos somados, dia a dia).
# - 50% = Coluna U ; 100% = Colunas V + W + X (sem carência, somadas normais)
# - Valor: 50% = valor_hora * horas_50 * 1.5 ; 100% = valor_hora * horas_100 * 2.0
# - Lê com openpyxl preservando durações > 24h ([h]:mm:ss)
# -----------------------------------------------------------------------------

import os
import re
import glob
import datetime
import pandas as pd
from openpyxl import load_workbook

# Configurações das colunas (Excel: U=21, V=22, W=23, X=24)
COL_U_IDX, COL_V_IDX, COL_W_IDX, COL_X_IDX = 21, 22, 23, 24
HEAD_U, HEAD_V, HEAD_W, HEAD_X = "U1", "V1", "W1", "X1"

# Títulos esperados na linha 1
EXPECTED_HEAD_U = "ExU50"
EXPECTED_HEAD_V = "ExS100"
EXPECTED_HEAD_W = "ExD100"
EXPECTED_HEAD_X = "ExF100"

SALARIOS_FILE = "salarios.xlsx"

# =============================================================================
# PARÂMETROS CONFIGURADOS COM BASE NA SUA PLANILHA REAL
# =============================================================================
MINUTOS_CARENCIA_50 = ${toleranceMinutes}        # Regra geral: apenas dias acima de ${toleranceMinutes} min são somados
MODO_EXCEDENTE = ${includeExcessOnly ? 'True' : 'False'}           # False = Integral CLT (soma tudo do dia); True = apenas excedente
LINHA_INICIO_DIAS = ${startRow}            # Linha 3 (ignora a Linha 2 de resumo 'Totais >>>')
APLICAR_REGRA_EM_100 = ${apply100Percent ? 'True' : 'False'}      # False = Horas 100% entram normais sem carência
# =============================================================================

ALIAS_TO_CANON = {'ExS5100': 'ExS100'}

def normalizar_rotulo(rotulo: str) -> str:
    r = str(rotulo).strip()
    return ALIAS_TO_CANON.get(r, r)

def cell_to_timedelta(value, number_format: str | None = None) -> pd.Timedelta:
    """Converte valor de célula Excel em pandas.Timedelta, preservando durações > 24h."""
    if value is None:
        return pd.Timedelta(0)

    if isinstance(value, datetime.timedelta):
        return pd.Timedelta(seconds=int(value.total_seconds()))

    if isinstance(value, datetime.time):
        return pd.Timedelta(hours=value.hour, minutes=value.minute, seconds=value.second)

    if isinstance(value, datetime.datetime):
        extra_days = max(value.day - 1, 0)
        return pd.Timedelta(hours=extra_days * 24 + value.hour, minutes=value.minute, seconds=value.second)

    if isinstance(value, (int, float)):
        total_seconds = round(float(value) * 24 * 3600)
        return pd.Timedelta(seconds=int(total_seconds))

    if isinstance(value, str):
        s = value.strip()
        m = re.search(r'(\\d{1,3}):(\\d{2})(?::(\\d{2}))?$', s)
        if m:
            h = int(m.group(1))
            mm = int(m.group(2))
            ss = int(m.group(3) or 0)
            return pd.Timedelta(hours=h, minutes=mm, seconds=ss)

    return pd.Timedelta(0)

def formatar_horas(td: pd.Timedelta) -> str:
    total_seconds = int(pd.to_timedelta(td).total_seconds())
    if total_seconds < 0:
        total_seconds = 0
    h = total_seconds // 3600
    m = (total_seconds % 3600) // 60
    return f"{h:02d}:{m:02d}"

def parse_valor_hora_coluna(col_series: pd.Series) -> pd.Series:
    """Converte coluna de salário/valor hora para float."""
    if pd.api.types.is_numeric_dtype(col_series):
        return col_series.astype(float)

    def parse_valor_hora(x):
        s = str(x).strip().replace('R$', '').replace(' ', '')
        if ',' in s and '.' in s:
            s = s.replace('.', '').replace(',', '.')
        elif ',' in s:
            s = s.replace(',', '.')
        return float(s or 0)

    return col_series.apply(parse_valor_hora)

def carregar_lista_excecoes(caminho_salarios: str) -> set:
    """
    Lê a aba 'excessão extra' (ou 'excecao extra', 'exceções', 'carencias')
    do arquivo salarios.xlsx e extrai os NOMES COMPLETOS dos colaboradores em exceção.
    """
    excecoes = set()
    try:
        wb_sal = load_workbook(caminho_salarios, data_only=True)
        aba_excecao = None
        
        for sheet_name in wb_sal.sheetnames:
            norm = sheet_name.strip().lower().replace('ç', 'c').replace('ã', 'a').replace('õ', 'o').replace(' ', '')
            if 'excess' in norm or 'excec' in norm or 'carencia' in norm:
                aba_excecao = wb_sal[sheet_name]
                print(f"Aba de exceções localizada: '{sheet_name}'")
                break

        if aba_excecao is not None:
            # Localiza a coluna exata de Nomes para não ler colunas de Cargo, Cidade ou Observação
            header_keywords = ['NOME', 'FUNCIONARIO', 'FUNCIONÁRIO', 'COLABORADOR', 'EMPREGADO', 'NOMES']
            col_nome = 1
            encontrou_header = False

            for r in range(1, min(aba_excecao.max_row + 1, 4)):
                for c in range(1, min(aba_excecao.max_column + 1, 10)):
                    val = aba_excecao.cell(row=r, column=c).value
                    if val:
                        txt = str(val).strip().upper()
                        if any(kw in txt for kw in header_keywords):
                            col_nome = c
                            encontrou_header = True
                            break
                if encontrou_header:
                    break

            blacklist = {
                'NOME', 'NOMES', 'NOME COMPLETO', 'FUNCIONARIO', 'FUNCIONÁRIO', 'COLABORADOR',
                'COLABORADORES', 'EXCEÇÃO', 'EXCESSÃO', 'CARÊNCIA', 'CARENCIA', 'SALARIO',
                'SALÁRIO', 'VALOR', 'CARGO', 'FUNÇÃO', 'FUNCAO', 'SETOR', 'DEPARTAMENTO',
                'CIDADE', 'ESTADO', 'OBS', 'OBSERVAÇÃO', 'OBSERVACOES', 'STATUS', 'MOTIVO',
                'TOTAL', 'TOTAIS', 'DATA', 'MATRICULA', 'MATRÍCULA', 'CPF'
            }

            for r in range(1, aba_excecao.max_row + 1):
                val = aba_excecao.cell(row=r, column=col_nome).value
                if val is not None:
                    nome_limpo = str(val).strip().upper()
                    if nome_limpo and nome_limpo not in blacklist:
                        if not re.match(r'^\d+(\.\d+)?$', nome_limpo) and len(nome_limpo) >= 3:
                            excecoes.add(nome_limpo)
        else:
            print("AVISO: Nenhuma aba de 'excessão extra' encontrada em 'salarios.xlsx'.")

        print(f"Total de funcionários na lista de exceção (identificação por NOME COMPLETO): {len(excecoes)}")
        for exc in sorted(list(excecoes)):
            print(f"  * Exceção ativa (nome completo): {exc}")
    except Exception as e:
        print(f"AVISO: Não foi possível ler a aba de exceções: {e}")

    return excecoes

PREPOSICOES = {'DE', 'DA', 'DO', 'DOS', 'DAS', 'E', 'D'}

def normalizar_texto_comparacao(texto: str) -> str:
    """Remove acentos, pontuação, múltiplos espaços e códigos de matrícula."""
    if not texto:
        return ""
    t = str(texto).strip().upper()
    t = unicodedata.normalize('NFKD', t)
    t = "".join([c for c in t if not unicodedata.combining(c)])
    # Remove prefixos numéricos como '01 - ' ou 'MATR. 123 - '
    t = re.sub(r'^(?:MATR(?:ICULA)?\.?\s*)?[0-9\-_./#:\s]+', '', t)
    # Remove sufixos numéricos como ' - 123' ou '(123)'
    t = re.sub(r'[-_/#:\s]*[([]?\d+[)\]]?\s*$', '', t)
    t = re.sub(r'[^A-Z\s]', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t

def get_core_tokens(nome_limpo: str) -> list:
    return [tok for tok in nome_limpo.split() if tok and tok not in PREPOSICOES]

def is_funcionario_excecao(nome_funcionario: str, lista_excecoes: set) -> bool:
    """
    Verifica se o funcionário consta na lista de exceções por NOME COMPLETO.
    Evita falsos positivos como confundir Adriano Santana com outro Santana.
    """
    nome_norm = normalizar_texto_comparacao(nome_funcionario)
    if not nome_norm:
        return False
    
    core_func = get_core_tokens(nome_norm)
    core_func_str = " ".join(core_func)

    for exc in lista_excecoes:
        exc_norm = normalizar_texto_comparacao(exc)
        if not exc_norm:
            continue
        
        # 1. Match exato de nome completo normalizado
        if nome_norm == exc_norm:
            return True
            
        # 2. Match de nome completo sem preposições (ex: 'ADRIANO DE SANTANA' == 'ADRIANO SANTANA')
        core_exc = get_core_tokens(exc_norm)
        core_exc_str = " ".join(core_exc)
        if core_func_str and core_exc_str and core_func_str == core_exc_str:
            return True
            
        # 3. Truncamento de aba do Excel (limite de 31 caracteres nas abas)
        if (len(nome_norm) >= 28 and exc_norm.startswith(nome_norm)) or \
           (len(exc_norm) >= 28 and nome_norm.startswith(exc_norm)):
            return True
                
    return False

def calcular_valores_financeiros(funcionario, horas50, horas100, df_salarios, dias_descartados_50=0, dias_considerados_50=0, eh_excecao=False):
    valor_hora = 0.0
    nome_procura = str(funcionario).strip().upper()
    try:
        for nome_salario in df_salarios.index:
            nome_idx = str(nome_salario).strip().upper()
            if nome_procura in nome_idx or nome_idx in nome_procura:
                valor_hora = float(df_salarios.loc[nome_salario, 'Valor Hora'])
                break
        
        if valor_hora == 0:
            print(f"  AVISO: Valor-hora para '{funcionario}' não encontrado em {SALARIOS_FILE}.")
            return None
    except Exception as e:
        print(f"  AVISO: Erro ao procurar salário para '{funcionario}': {e}")
        return None

    h50  = horas50.total_seconds()  / 3600.0
    h100 = horas100.total_seconds() / 3600.0

    total50  = (valor_hora * h50)  * 1.5
    total100 = (valor_hora * h100) * 2.0
    total    = total50 + total100

    return {
        'NOME DO FUNCIONÁRIO': funcionario,
        'REGRA': 'EXCEÇÃO (CADA MINUTO)' if eh_excecao else 'GERAL (> 19 MIN)',
        'EXTRAS 50%':   formatar_horas(horas50),
        'TOTAL 50%':    total50,
        'EXTRAS 100%':  formatar_horas(horas100),
        'TOTAL 100%':   total100,
        'TOTAL':        total,
        'DIAS 50% APROV. (> ${toleranceMinutes}m)': dias_considerados_50,
        'DIAS 50% DESC. (<= ${toleranceMinutes}m)': dias_descartados_50
    }

def processar_arquivos_ponto():
    caminho = None
    df_sal = None
    try:
        if not os.path.exists(SALARIOS_FILE):
            print(f"ERRO: Arquivo '{SALARIOS_FILE}' não encontrado.")
            return

        # Carrega salários (primeira aba ou aba Salarios)
        df_sal = pd.read_excel(SALARIOS_FILE, sheet_name=0)
        df_sal['Valor Hora'] = parse_valor_hora_coluna(df_sal.iloc[:, 1])
        df_sal.set_index(df_sal.columns[0], inplace=True)

        # Carrega a lista de exceções da aba 'excessão extra'
        lista_excecoes = carregar_lista_excecoes(SALARIOS_FILE)

        arquivos_xlsx = [
            f for f in glob.glob("*.xlsx") 
            if "ponto" in f.lower() and "-lido" not in f.lower()
        ]
        
        if not arquivos_xlsx:
            print("ERRO: Nenhum arquivo XLSX com 'ponto' no nome (e sem '-lido') foi encontrado.")
            return
        
        caminho = arquivos_xlsx[0]
        print(f"Processando arquivo de ponto: {caminho}")

        wb = load_workbook(caminho, data_only=True)
        dados_relatorio = []
        layout_valido = True
        erros_de_salario = []

        limite_segundos_50 = MINUTOS_CARENCIA_50 * 60

        for ws in wb.worksheets:
            funcionario = ws.title
            
            # Validação do cabeçalho na linha 1
            try:
                head_u = normalizar_rotulo(str(ws[HEAD_U].value).strip())
                head_v = normalizar_rotulo(str(ws[HEAD_V].value).strip())
                head_w = normalizar_rotulo(str(ws[HEAD_W].value).strip())
                head_x = normalizar_rotulo(str(ws[HEAD_X].value).strip())

                erros_layout = []
                if head_u != EXPECTED_HEAD_U:
                    erros_layout.append(f"Coluna U1 esperava '{EXPECTED_HEAD_U}' mas encontrou '{head_u}'")
                if head_v != EXPECTED_HEAD_V:
                    erros_layout.append(f"Coluna V1 esperava '{EXPECTED_HEAD_V}' mas encontrou '{head_v}'")
                if head_w != EXPECTED_HEAD_W:
                    erros_layout.append(f"Coluna W1 esperava '{EXPECTED_HEAD_W}' mas encontrou '{head_w}'")
                if head_x != EXPECTED_HEAD_X:
                    erros_layout.append(f"Coluna X1 esperava '{EXPECTED_HEAD_X}' mas encontrou '{head_x}'")

                if erros_layout:
                    print(f"\\nERRO DE LAYOUT na aba '{funcionario}':")
                    for erro in erros_layout:
                        print(f"  - {erro}")
                    layout_valido = False
                    continue

            except Exception as e:
                print(f"\\nERRO GRAVE DE LAYOUT na aba '{funcionario}': {e}")
                layout_valido = False
                continue

            # Verifica se este funcionário é EXCEÇÃO (calcula cada minuto)
            eh_excecao = is_funcionario_excecao(funcionario, lista_excecoes)
            if eh_excecao:
                print(f"  -> '{funcionario}' está na aba 'excessão extra': calculando CADA MINUTO sem carência!")

            # --- SOMA DIÁRIA ---
            horas50_acumuladas = pd.Timedelta(0)
            horas100_acumuladas = pd.Timedelta(0)
            dias_descartados_50 = 0
            dias_considerados_50 = 0

            max_linha = ws.max_row
            
            for row in range(LINHA_INICIO_DIAS, max_linha + 1):
                # Pula explicitamente se for a linha 2 (resumo 'Totais >>>')
                if row == 2:
                    continue

                # Células da linha atual
                cell_u = ws.cell(row=row, column=COL_U_IDX)
                cell_v = ws.cell(row=row, column=COL_V_IDX)
                cell_w = ws.cell(row=row, column=COL_W_IDX)
                cell_x = ws.cell(row=row, column=COL_X_IDX)

                # Se a linha for cabeçalho/resumo de 'Total' ou 'Totais', ignora
                val_u_str = str(cell_u.value or '').strip().lower()
                primeira_celula = str(ws.cell(row=row, column=1).value or '').strip().lower()
                if ('total' in val_u_str or 'totais' in val_u_str or 
                    'total' in primeira_celula or 'totais' in primeira_celula or 
                    'resumo' in val_u_str):
                    continue

                # Coluna U: 50%
                td_dia_50 = cell_to_timedelta(cell_u.value, cell_u.number_format)
                segundos_50 = td_dia_50.total_seconds()

                if eh_excecao:
                    # REGRA DE EXCEÇÃO: Calcula CADA MINUTO (sem tolerância)
                    if segundos_50 > 0:
                        dias_considerados_50 += 1
                        horas50_acumuladas += td_dia_50
                else:
                    # REGRA GERAL: Só soma se no dia tiver feito ACIMA de ${toleranceMinutes} minutos
                    if segundos_50 > limite_segundos_50:
                        dias_considerados_50 += 1
                        if MODO_EXCEDENTE:
                            horas50_acumuladas += pd.Timedelta(seconds=segundos_50 - limite_segundos_50)
                        else:
                            horas50_acumuladas += td_dia_50  # Soma integral
                    elif segundos_50 > 0:
                        # Menor ou igual a ${toleranceMinutes} minutos: descartado da soma total!
                        dias_descartados_50 += 1
                        val_formatado = formatar_horas(td_dia_50)
                        data_str = str(ws.cell(row=row, column=2).value or ws.cell(row=row, column=1).value or f"Linha {row}")
                        print(f"  [DESCARTADO] {funcionario} | {data_str} (Linha {row}): {val_formatado} em ExU50 (<= {MINUTOS_CARENCIA_50} min carência)")

                # Extras 100% (V + W + X: ExS100, ExD100, ExF100)
                td_v = cell_to_timedelta(cell_v.value, cell_v.number_format)
                td_w = cell_to_timedelta(cell_w.value, cell_w.number_format)
                td_x = cell_to_timedelta(cell_x.value, cell_x.number_format)
                td_dia_100 = td_v + td_w + td_x
                segundos_100 = td_dia_100.total_seconds()

                if APLICAR_REGRA_EM_100 and not eh_excecao:
                    if segundos_100 > limite_segundos_50:
                        horas100_acumuladas += td_dia_100
                else:
                    horas100_acumuladas += td_dia_100  # Soma normal sem carência

            # Cálculo financeiro com as horas acumuladas
            resultado = calcular_valores_financeiros(
                funcionario, 
                horas50_acumuladas, 
                horas100_acumuladas, 
                df_sal,
                dias_descartados_50,
                dias_considerados_50,
                eh_excecao
            )

            if resultado is None:
                erros_de_salario.append(funcionario)
            else:
                dados_relatorio.append(resultado)

        if not layout_valido:
            print("\\nProcessamento interrompido devido a erros de layout.")
            return

        if erros_de_salario:
            # Auto cadastro no salarios.xlsx se faltar
            nomes_a_adicionar = []
            nomes_faltando_unicos = sorted(list(set(erros_de_salario)))
            nomes_existentes_upper = [str(n).strip().upper() for n in df_sal.index]

            for nome_novo in nomes_faltando_unicos:
                if nome_novo.strip().upper() not in nomes_existentes_upper:
                    nomes_a_adicionar.append(nome_novo)

            if nomes_a_adicionar:
                try:
                    wb_sal = load_workbook(SALARIOS_FILE)
                    ws_sal = wb_sal.active
                    prox_linha = ws_sal.max_row + 1
                    for i, nome in enumerate(nomes_a_adicionar):
                        ws_sal.cell(row=prox_linha + i, column=1, value=nome)
                    wb_sal.save(SALARIOS_FILE)
                    print(f"\\nAVISO: {len(nomes_a_adicionar)} funcionário(s) novo(s) adicionado(s) ao '{SALARIOS_FILE}'.")
                except Exception as e:
                    print(f"\\nAVISO: Falha ao adicionar nomes novos ao '{SALARIOS_FILE}': {e}")

            print(f"\\nERRO: O 'Valor Hora' dos seguintes funcionários não foi encontrado no '{SALARIOS_FILE}':")
            for nome in nomes_faltando_unicos:
                print(f"  - {nome}")
            return

        if not dados_relatorio:
            print("Nenhum dado processado.")
            return

        out = "EXTRAS CALCULADAS.xlsx"
        df_rel = pd.DataFrame(dados_relatorio)
        col_order = ['NOME DO FUNCIONÁRIO', 'REGRA', 'EXTRAS 50%', 'TOTAL 50%',
                     'EXTRAS 100%', 'TOTAL 100%', 'TOTAL', 
                     'DIAS 50% APROV. (> ${toleranceMinutes}m)', 'DIAS 50% DESC. (<= ${toleranceMinutes}m)']
        df_rel = df_rel[[c for c in col_order if c in df_rel.columns]]

        with pd.ExcelWriter(out, engine='openpyxl') as writer:
            df_rel.to_excel(writer, index=False, sheet_name='Relatorio')
            ws_out = writer.sheets['Relatorio']

            formato_moeda = 'R$ #,##0.00'
            header_map = {cell.value: cell.column for cell in ws_out[1]}
            from openpyxl.utils import get_column_letter
            for name in ['TOTAL 50%', 'TOTAL 100%', 'TOTAL']:
                if name in header_map:
                    col_letter = get_column_letter(header_map[name])
                    for r in range(2, ws_out.max_row + 1):
                        ws_out[f"{col_letter}{r}"].number_format = formato_moeda

            for col_cells in ws_out.columns:
                length = max(len(str(cell.value or '')) for cell in col_cells)
                col_letter = col_cells[0].column_letter
                ws_out.column_dimensions[col_letter].width = max(length + 3, 14)

        print(f"\\nRelatório gerado com sucesso: '{out}'")
        
        # Renomeia para -lido
        if caminho:
            base, ext = os.path.splitext(caminho)
            novo = f"{base}-lido{ext}"
            os.rename(caminho, novo)
            print(f"Arquivo renomeado para '{novo}'.")

    except Exception as e:
        print(f"\\nErro inesperado: {e}")

if __name__ == "__main__":
    try:
        processar_arquivos_ponto()
    finally:
        input("\\nPressione ENTER para fechar...")
`;
};

// Sample mock days for demonstration
interface DayMock {
  day: number;
  exU50: string; // "00:15", "00:25", etc.
  ex100: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'explanation' | 'simulator' | 'python' | 'tester'>('explanation');

  // Configuration options
  const [toleranceMinutes, setToleranceMinutes] = useState<number>(19);
  const [startRow, setStartRow] = useState<number>(3);
  const [includeExcessOnly, setIncludeExcessOnly] = useState<boolean>(false);
  const [apply100Percent, setApply100Percent] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Simulator sample days
  const [hourlyRate, setHourlyRate] = useState<number>(18.50);
  const [sampleDays, setSampleDays] = useState<DayMock[]>([
    { day: 1, exU50: "00:15", ex100: "00:00" }, // <= 19 -> Descartado
    { day: 2, exU50: "00:25", ex100: "00:00" }, // > 19 -> Considerado
    { day: 3, exU50: "00:19", ex100: "00:00" }, // <= 19 -> Descartado
    { day: 4, exU50: "00:45", ex100: "01:00" }, // > 19 -> Considerado
    { day: 5, exU50: "00:08", ex100: "00:00" }, // <= 19 -> Descartado
    { day: 6, exU50: "01:10", ex100: "00:00" }, // > 19 -> Considerado
    { day: 7, exU50: "00:20", ex100: "00:00" }, // > 19 -> Considerado (20 min)
  ]);

  // File tester states
  const [pontoFileName, setPontoFileName] = useState<string>('');
  const [salariosFileName, setSalariosFileName] = useState<string>('');
  const [salariosMap, setSalariosMap] = useState<Record<string, number>>({});
  const [excecoesList, setExcecoesList] = useState<string[]>([]);
  const [newExcecaoInput, setNewExcecaoInput] = useState<string>('');
  const [uploadError, setUploadError] = useState<string>('');
  const [selectedEmployeeDetail, setSelectedEmployeeDetail] = useState<any | null>(null);
  const [processedResults, setProcessedResults] = useState<Array<{
    nome: string;
    ehExcecao: boolean;
    extras50: string;
    total50: number;
    extras100: string;
    total100: number;
    totalGeral: number;
    diasAprovados: number;
    diasDescartados: number;
    detalhesDias: Array<{
      linha: number;
      labelDia: string;
      data: string;
      exU50Str: string;
      sec50: number;
      ex100Str: string;
      status50: 'aprovado' | 'descartado' | 'zerado';
      motivo: string;
    }>;
  }>>([
    {
      nome: "IVANILTON",
      ehExcecao: true,
      extras50: "09:00",
      total50: 249.75,
      extras100: "02:00",
      total100: 74.00,
      totalGeral: 323.75,
      diasAprovados: 13,
      diasDescartados: 0,
      detalhesDias: [
        { linha: 3, labelDia: "Dia 01", data: "01/09/2026 Qua", exU50Str: "00:45", sec50: 2700, ex100Str: "00:00", status50: "aprovado", motivo: "Exceção (Aba Excessão): cada minuto vale (00:45 somado)" },
        { linha: 4, labelDia: "Dia 02", data: "02/09/2026 Qui", exU50Str: "01:10", sec50: 4200, ex100Str: "00:00", status50: "aprovado", motivo: "Exceção (Aba Excessão): cada minuto vale (01:10 somado)" },
        { linha: 5, labelDia: "Dia 03", data: "03/09/2026 Sex", exU50Str: "00:15", sec50: 900, ex100Str: "00:00", status50: "aprovado", motivo: "Exceção (Aba Excessão): 00:15 SOMADO INTEGRALMENTE (sem descarte!)" },
        { linha: 6, labelDia: "Dia 04", data: "04/09/2026 Sab", exU50Str: "00:00", sec50: 0, ex100Str: "02:00", status50: "zerado", motivo: "Sem extras 50% neste dia (100% normal)" },
        { linha: 7, labelDia: "Dia 05", data: "05/09/2026 Dom", exU50Str: "00:00", sec50: 0, ex100Str: "00:00", status50: "zerado", motivo: "Sem extras 50% neste dia" },
        { linha: 8, labelDia: "Dia 06", data: "06/09/2026 Seg", exU50Str: "00:30", sec50: 1800, ex100Str: "00:00", status50: "aprovado", motivo: "Exceção (Aba Excessão): cada minuto vale (00:30 somado)" },
        { linha: 9, labelDia: "Dia 07", data: "07/09/2026 Ter", exU50Str: "00:20", sec50: 1200, ex100Str: "00:00", status50: "aprovado", motivo: "Exceção (Aba Excessão): cada minuto vale (00:20 somado)" }
      ]
    },
    {
      nome: "FUNCIONÁRIO PADRÃO (Regra Geral)",
      ehExcecao: false,
      extras50: "08:45",
      total50: 242.81,
      extras100: "00:00",
      total100: 0.00,
      totalGeral: 242.81,
      diasAprovados: 12,
      diasDescartados: 1,
      detalhesDias: [
        { linha: 3, labelDia: "Dia 01", data: "01/09/2026 Qua", exU50Str: "00:45", sec50: 2700, ex100Str: "00:00", status50: "aprovado", motivo: "Ultrapassou 19 min (soma integral: 00:45)" },
        { linha: 4, labelDia: "Dia 02", data: "02/09/2026 Qui", exU50Str: "01:10", sec50: 4200, ex100Str: "00:00", status50: "aprovado", motivo: "Ultrapassou 19 min (soma integral: 01:10)" },
        { linha: 5, labelDia: "Dia 03", data: "03/09/2026 Sex", exU50Str: "00:15", sec50: 900, ex100Str: "00:00", status50: "descartado", motivo: "Feito 00:15 (<= 19 min carência descartado na Regra Geral)" }
      ]
    }
  ]);

  // Time conversion helper for XLSX values
  const parseCellSeconds = (val: any): number => {
    if (val === null || val === undefined || val === '') return 0;
    if (typeof val === 'number') {
      // Excel day fraction
      return Math.round(val * 24 * 3600);
    }
    const str = String(val).trim();
    const match = str.match(/(\d{1,3}):(\d{2})(?::(\d{2}))?$/);
    if (match) {
      const h = parseInt(match[1], 10);
      const m = parseInt(match[2], 10);
      const s = parseInt(match[3] || '0', 10);
      return h * 3600 + m * 60 + s;
    }
    return 0;
  };

  const formatSecondsToHHMM = (totalSec: number) => {
    if (totalSec <= 0) return "00:00";
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  };

  // Limpa e normaliza para comparação estrita de NOME COMPLETO:
  // Remove acentos, pontuação, números de matrícula/ID no início ou fim
  const cleanCompareName = (text: string): string => {
    if (!text) return '';
    return text
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // remove acentos
      .toUpperCase()
      // Remove prefixos como '01 - ', '0023 ', 'MATR. 123 - '
      .replace(/^(?:MATR(?:ICULA)?\.?\s*)?[0-9\-_./#:\s]+/, '')
      // Remove sufixos como ' - 123', ' (0012)', ' [99]'
      .replace(/[-_/#:\s]*[([]?\d+[)\]]?\s*$/, '')
      .replace(/[^A-Z\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const PREPOSITIONS = new Set(['DE', 'DA', 'DO', 'DOS', 'DAS', 'E', 'D']);

  const getCoreTokens = (cleanedName: string): string[] => {
    return cleanedName
      .split(' ')
      .filter(t => t.length > 0 && !PREPOSITIONS.has(t));
  };

  // Comparação ESTRITA DE NOME COMPLETO:
  // Evita erros de leitura (ex: não marca "ADRIANO SANTANA" só porque outro colaborador tem sobrenome Santana)
  const checkEmployeeIsExcecao = (empName: string, list: string[]): boolean => {
    const normEmp = cleanCompareName(empName);
    if (!normEmp) return false;
    const coreEmp = getCoreTokens(normEmp);
    const coreEmpStr = coreEmp.join(' ');

    return list.some(exc => {
      const normExc = cleanCompareName(exc);
      if (!normExc) return false;

      // 1. Match exato de nome completo normalizado
      if (normEmp === normExc) return true;

      // 2. Match de nome completo sem preposições (ex: 'ADRIANO DE SANTANA' == 'ADRIANO SANTANA')
      const coreExc = getCoreTokens(normExc);
      const coreExcStr = coreExc.join(' ');
      if (coreEmpStr && coreExcStr && coreEmpStr === coreExcStr) return true;

      // 3. Truncamento de aba do Excel (limite nativo de 31 caracteres nas abas)
      if (
        (normEmp.length >= 28 && normExc.startsWith(normEmp)) ||
        (normExc.length >= 28 && normEmp.startsWith(normExc))
      ) {
        return true;
      }

      return false;
    });
  };

  // Recalcula resultados dia a dia quando as exceções ou parâmetros mudam
  const recalculateAllResults = (
    currentResults: typeof processedResults,
    activeExceptions: string[],
    tolerance: number,
    excessOnly: boolean,
    apply100: boolean,
    salMap: Record<string, number>
  ) => {
    const limitSec = tolerance * 60;
    return currentResults.map(emp => {
      const isExc = checkEmployeeIsExcecao(emp.nome, activeExceptions);
      let totalSec50 = 0;
      let totalSec100 = 0;
      let diasAprov = 0;
      let diasDesc = 0;

      const updatedDetalhes = emp.detalhesDias.map(d => {
        const sec50 = d.sec50;
        const sec100 = parseCellSeconds(d.ex100Str);

        let status50: 'aprovado' | 'descartado' | 'zerado' = 'zerado';
        let motivo = '';

        if (isExc) {
          if (sec50 > 0) {
            diasAprov++;
            totalSec50 += sec50;
            status50 = 'aprovado';
            motivo = 'Exceção (Nome Completo): cada minuto calculado';
          } else {
            status50 = 'zerado';
            motivo = 'Sem extras 50% neste dia';
          }
        } else {
          if (sec50 > limitSec) {
            diasAprov++;
            totalSec50 += excessOnly ? Math.max(0, sec50 - limitSec) : sec50;
            status50 = 'aprovado';
            motivo = `Ultrapassou ${tolerance} min (soma integral: ${d.exU50Str})`;
          } else if (sec50 > 0) {
            diasDesc++;
            status50 = 'descartado';
            motivo = `Feito ${d.exU50Str} (<= ${tolerance} min carência descartado)`;
          } else {
            status50 = 'zerado';
            motivo = 'Sem extras 50% neste dia';
          }
        }

        if (apply100 && !isExc) {
          if (sec100 > limitSec) totalSec100 += sec100;
        } else {
          totalSec100 += sec100;
        }

        return {
          ...d,
          status50,
          motivo
        };
      });

      let rate = hourlyRate;
      const normEmp = cleanCompareName(emp.nome);
      const coreEmpStr = getCoreTokens(normEmp).join(' ');
      for (const key of Object.keys(salMap)) {
        const normKey = cleanCompareName(key);
        const coreKeyStr = getCoreTokens(normKey).join(' ');
        if (normEmp === normKey || (coreEmpStr && coreKeyStr && coreEmpStr === coreKeyStr)) {
          rate = salMap[key];
          break;
        }
      }

      const h50Dec = totalSec50 / 3600;
      const h100Dec = totalSec100 / 3600;
      const total50 = h50Dec * rate * 1.5;
      const total100 = h100Dec * rate * 2.0;
      const totalGeral = total50 + total100;

      return {
        ...emp,
        ehExcecao: isExc,
        extras50: formatSecondsToHHMM(totalSec50),
        total50,
        extras100: formatSecondsToHHMM(totalSec100),
        total100,
        totalGeral,
        diasAprovados: diasAprov,
        diasDescartados: diasDesc,
        detalhesDias: updatedDetalhes
      };
    });
  };

  // Salarios upload (including detection of 'excessão extra' tab)
  const handleSalariosFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError('');
    const file = e.target.files?.[0];
    if (!file) return;
    setSalariosFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        
        // 1. Read Salarios tab (first sheet)
        const firstSheetName = wb.SheetNames[0];
        const ws = wb.Sheets[firstSheetName];
        const json: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1 });

        const newMap: Record<string, number> = {};
        for (let r = 1; r < json.length; r++) {
          const row = json[r];
          if (!row || row.length < 2) continue;
          const nome = String(row[0] || '').trim().toUpperCase();
          let valorStr = String(row[1] || '').replace('R$', '').trim();
          if (valorStr.includes(',') && valorStr.includes('.')) {
            valorStr = valorStr.replace('.', '').replace(',', '.');
          } else if (valorStr.includes(',')) {
            valorStr = valorStr.replace(',', '.');
          }
          const num = parseFloat(valorStr);
          if (nome && !isNaN(num)) {
            newMap[nome] = num;
          }
        }
        setSalariosMap(newMap);

        // 2. Read 'excessão extra' tab (extrai NOMES COMPLETOS da coluna correta)
        const detectedExcecoes: string[] = [];
        for (const sName of wb.SheetNames) {
          const sNorm = sName.trim().toLowerCase().replace('ç', 'c').replace('ã', 'a').replace('õ', 'o').replace(/\s+/g, '');
          const isExceptionSheet = sNorm.includes('excess') || sNorm.includes('excec') || sNorm.includes('carencia');
          
          if (isExceptionSheet) {
            const wsExc = wb.Sheets[sName];
            const rowsExc: any[][] = XLSX.utils.sheet_to_json(wsExc, { header: 1 });
            if (rowsExc && rowsExc.length > 0) {
              // Localiza a coluna de nomes para não ler colunas de cargo, cidade, etc.
              let nameColIdx = 0;
              let foundHeaderCol = -1;
              const headerKeywords = ['NOME', 'FUNCIONARIO', 'FUNCIONÁRIO', 'COLABORADOR', 'EMPREGADO', 'NOMES'];

              for (let r = 0; r < Math.min(rowsExc.length, 4); r++) {
                const rData = rowsExc[r] || [];
                for (let c = 0; c < rData.length; c++) {
                  const cellText = String(rData[c] || '').trim().toUpperCase();
                  if (headerKeywords.some(kw => cellText.includes(kw))) {
                    foundHeaderCol = c;
                    break;
                  }
                }
                if (foundHeaderCol !== -1) break;
              }

              if (foundHeaderCol !== -1) {
                nameColIdx = foundHeaderCol;
              } else {
                // Se a col 0 é numérica (ex: contador 1, 2, 3), verifica se a col 1 tem nomes
                const sample0 = rowsExc.slice(0, 5).map(r => String(r[0] || '').trim());
                const sample1 = rowsExc.slice(0, 5).map(r => String(r[1] || '').trim());
                if (sample0.some(s => /^\d+$/.test(s)) && sample1.some(s => s.length >= 3 && !/^\d+$/.test(s))) {
                  nameColIdx = 1;
                }
              }

              const blacklist = new Set([
                'NOME', 'NOMES', 'NOME COMPLETO', 'FUNCIONARIO', 'FUNCIONÁRIO', 'COLABORADOR',
                'COLABORADORES', 'EXCEÇÃO', 'EXCESSÃO', 'CARÊNCIA', 'CARENCIA', 'SALARIO',
                'SALÁRIO', 'VALOR', 'CARGO', 'FUNÇÃO', 'FUNCAO', 'SETOR', 'DEPARTAMENTO',
                'CIDADE', 'ESTADO', 'OBS', 'OBSERVAÇÃO', 'OBSERVACOES', 'STATUS', 'MOTIVO',
                'TOTAL', 'TOTAIS', 'DATA', 'MATRICULA', 'MATRÍCULA', 'CPF'
              ]);

              for (let r = 0; r < rowsExc.length; r++) {
                const val = rowsExc[r]?.[nameColIdx];
                if (val !== undefined && val !== null) {
                  const nomeExc = String(val).trim().toUpperCase();
                  if (nomeExc && !blacklist.has(nomeExc)) {
                    if (!/^\d+(\.\d+)?$/.test(nomeExc) && nomeExc.length >= 3) {
                      if (!detectedExcecoes.includes(nomeExc)) {
                        detectedExcecoes.push(nomeExc);
                      }
                    }
                  }
                }
              }
            }
          }
        }

        if (detectedExcecoes.length > 0) {
          setExcecoesList(detectedExcecoes);
          setProcessedResults(prev => recalculateAllResults(prev, detectedExcecoes, toleranceMinutes, includeExcessOnly, apply100Percent, newMap));
        }
      } catch (err: any) {
        setUploadError(`Erro ao ler salários: ${err?.message || err}`);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Ponto upload and processing
  const handlePontoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError('');
    const file = e.target.files?.[0];
    if (!file) return;
    setPontoFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });

        const results: Array<{
          nome: string;
          ehExcecao: boolean;
          extras50: string;
          total50: number;
          extras100: string;
          total100: number;
          totalGeral: number;
          diasAprovados: number;
          diasDescartados: number;
          detalhesDias: Array<{
            linha: number;
            labelDia: string;
            data: string;
            exU50Str: string;
            sec50: number;
            ex100Str: string;
            status50: 'aprovado' | 'descartado' | 'zerado';
            motivo: string;
          }>;
        }> = [];

        const limitSec = toleranceMinutes * 60;

        wb.SheetNames.forEach((sheetName) => {
          const ws = wb.Sheets[sheetName];
          const rows: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1 });
          if (!rows || rows.length < 2) return;

          // Header line
          const header = rows[0] || [];
          let colU = 20; // Default U (0-indexed)
          let colV = 21; // V
          let colW = 22; // W
          let colX = 23; // X

          // Search header indices if named
          header.forEach((val, idx) => {
            const h = String(val || '').trim().toUpperCase();
            if (h === 'EXU50') colU = idx;
            if (h === 'EXS100' || h === 'EXS5100') colV = idx;
            if (h === 'EXD100') colW = idx;
            if (h === 'EXF100') colX = idx;
          });

          let employeeFullName = sheetName;
          for (let r = 0; r < Math.min(rows.length, 5); r++) {
            const rData = rows[r] || [];
            for (let c = 0; c < rData.length; c++) {
              const val = String(rData[c] || '');
              if (/funcion[aá]rio\s*:\s*(.+)/i.test(val)) {
                const match = val.match(/funcion[aá]rio\s*:\s*(.+)/i);
                if (match && match[1]?.trim()) {
                  employeeFullName = match[1].trim();
                  break;
                }
              }
            }
          }

          // Identificação estrita por NOME COMPLETO na lista de exceções
          const isExcecao = checkEmployeeIsExcecao(sheetName, excecoesList) || 
                            (employeeFullName !== sheetName && checkEmployeeIsExcecao(employeeFullName, excecoesList));

          let totalSec50 = 0;
          let totalSec100 = 0;
          let diasAprovados = 0;
          let diasDescartados = 0;
          const detalhesDias: Array<{
            linha: number;
            labelDia: string;
            data: string;
            exU50Str: string;
            sec50: number;
            ex100Str: string;
            status50: 'aprovado' | 'descartado' | 'zerado';
            motivo: string;
          }> = [];

          // Start scanning from startRow (1-indexed -> 0-indexed is startRow - 1)
          const startIdx = Math.max(1, startRow - 1);
          for (let r = startIdx; r < rows.length; r++) {
            // Excel row 2 is index 1 -> Skip system Totais row
            if (r === 1) continue;

            const row = rows[r];
            if (!row) continue;

            // Check if it's a Total row
            const firstCell = String(row[0] || '').toLowerCase();
            const uCellStr = String(row[colU] || '').toLowerCase();
            if (firstCell.includes('total') || firstCell.includes('totais') || uCellStr.includes('total') || uCellStr.includes('totais')) {
              continue;
            }

            // Coluna U: 50%
            const sec50 = parseCellSeconds(row[colU]);
            const exU50Str = formatSecondsToHHMM(sec50);

            // Colunas V, W, X: 100%
            const secV = parseCellSeconds(row[colV]);
            const secW = parseCellSeconds(row[colW]);
            const secX = parseCellSeconds(row[colX]);
            const sec100 = secV + secW + secX;
            const ex100Str = formatSecondsToHHMM(sec100);

            const linhaExcel = r + 1;
            const labelDia = String(row[0] || `Linha ${linhaExcel}`);
            const dataStr = String(row[1] || '');

            if (isExcecao) {
              // EXCEÇÃO: Calcula cada minuto sem carência
              if (sec50 > 0) {
                diasAprovados++;
                totalSec50 += sec50;
                detalhesDias.push({
                  linha: linhaExcel,
                  labelDia,
                  data: dataStr,
                  exU50Str,
                  sec50,
                  ex100Str,
                  status50: 'aprovado',
                  motivo: 'Exceção: cada minuto é calculado integralmente'
                });
              } else {
                detalhesDias.push({
                  linha: linhaExcel,
                  labelDia,
                  data: dataStr,
                  exU50Str,
                  sec50: 0,
                  ex100Str,
                  status50: 'zerado',
                  motivo: 'Sem extras 50% neste dia'
                });
              }
            } else {
              // REGRA GERAL: Só soma se > toleranceMinutes
              if (sec50 > limitSec) {
                diasAprovados++;
                if (includeExcessOnly) {
                  totalSec50 += Math.max(0, sec50 - limitSec);
                } else {
                  totalSec50 += sec50;
                }
                detalhesDias.push({
                  linha: linhaExcel,
                  labelDia,
                  data: dataStr,
                  exU50Str,
                  sec50,
                  ex100Str,
                  status50: 'aprovado',
                  motivo: `Ultrapassou ${toleranceMinutes} min (soma integral: ${exU50Str})`
                });
              } else if (sec50 > 0) {
                diasDescartados++;
                detalhesDias.push({
                  linha: linhaExcel,
                  labelDia,
                  data: dataStr,
                  exU50Str,
                  sec50,
                  ex100Str,
                  status50: 'descartado',
                  motivo: `Feito ${exU50Str} (<= ${toleranceMinutes} min carência descartado)`
                });
              } else {
                detalhesDias.push({
                  linha: linhaExcel,
                  labelDia,
                  data: dataStr,
                  exU50Str,
                  sec50: 0,
                  ex100Str,
                  status50: 'zerado',
                  motivo: 'Sem extras 50% neste dia'
                });
              }
            }

            if (apply100Percent && !isExcecao) {
              if (sec100 > limitSec) {
                totalSec100 += sec100;
              }
            } else {
              totalSec100 += sec100;
            }
          }

          // Busca de taxa horária por NOME COMPLETO
          let rate = hourlyRate;
          const normEmpSheet = cleanCompareName(employeeFullName || sheetName);
          const coreEmpStr = getCoreTokens(normEmpSheet).join(' ');
          for (const key of Object.keys(salariosMap)) {
            const normKey = cleanCompareName(key);
            const coreKeyStr = getCoreTokens(normKey).join(' ');
            if (normEmpSheet === normKey || (coreEmpStr && coreKeyStr && coreEmpStr === coreKeyStr)) {
              rate = salariosMap[key];
              break;
            }
          }

          const h50Dec = totalSec50 / 3600;
          const h100Dec = totalSec100 / 3600;
          const total50 = h50Dec * rate * 1.5;
          const total100 = h100Dec * rate * 2.0;
          const totalGeral = total50 + total100;

          results.push({
            nome: employeeFullName || sheetName,
            ehExcecao: isExcecao,
            extras50: formatSecondsToHHMM(totalSec50),
            total50,
            extras100: formatSecondsToHHMM(totalSec100),
            total100,
            totalGeral,
            diasAprovados,
            diasDescartados,
            detalhesDias
          });
        });

        if (results.length === 0) {
          setUploadError('Nenhuma aba válida encontrada no arquivo selecionado.');
        } else {
          setProcessedResults(results);
        }
      } catch (err: any) {
        setUploadError(`Erro ao processar arquivo de ponto: ${err?.message || err}`);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Export results to Excel
  const handleExportCalculatedExcel = () => {
    if (processedResults.length === 0) return;
    const wb = XLSX.utils.book_new();

    const dataRows = processedResults.map(r => ({
      'NOME DO FUNCIONÁRIO': r.nome,
      'REGRA APLICADA': r.ehExcecao ? 'EXCEÇÃO (CADA MINUTO)' : `GERAL (> ${toleranceMinutes}m)`,
      'EXTRAS 50%': r.extras50,
      'TOTAL 50%': Number(r.total50.toFixed(2)),
      'EXTRAS 100%': r.extras100,
      'TOTAL 100%': Number(r.total100.toFixed(2)),
      'TOTAL': Number(r.totalGeral.toFixed(2)),
      [`DIAS 50% APROV. (> ${toleranceMinutes}m)`]: r.diasAprovados,
      [`DIAS 50% DESC. (<= ${toleranceMinutes}m)`]: r.diasDescartados,
    }));

    const ws = XLSX.utils.json_to_sheet(dataRows);
    XLSX.utils.book_append_sheet(wb, ws, 'Relatorio');
    XLSX.writeFile(wb, 'EXTRAS CALCULADAS.xlsx');
  };

  // Compute simulator results
  const simulationResults = useMemo(() => {
    let totalSeconds50 = 0;
    let totalSeconds100 = 0;
    let discardedDaysCount = 0;
    let approvedDaysCount = 0;

    const limitSeconds = toleranceMinutes * 60;

    const evaluatedDays = sampleDays.map(item => {
      // Parse 50%
      const [h50, m50] = item.exU50.split(':').map(Number);
      const sec50 = (h50 || 0) * 3600 + (m50 || 0) * 60;
      const isApproved50 = sec50 > limitSeconds;

      let countedSec50 = 0;
      if (isApproved50) {
        approvedDaysCount++;
        countedSec50 = includeExcessOnly ? Math.max(0, sec50 - limitSeconds) : sec50;
        totalSeconds50 += countedSec50;
      } else if (sec50 > 0) {
        discardedDaysCount++;
      }

      // Parse 100%
      const [h100, m100] = item.ex100.split(':').map(Number);
      const sec100 = (h100 || 0) * 3600 + (m100 || 0) * 60;
      let isApproved100 = true;
      if (apply100Percent) {
        isApproved100 = sec100 > limitSeconds;
      }
      if (isApproved100) {
        totalSeconds100 += sec100;
      }

      return {
        ...item,
        sec50,
        sec100,
        isApproved50,
        countedSec50,
        isApproved100
      };
    });

    const hours50Decimal = totalSeconds50 / 3600;
    const hours100Decimal = totalSeconds100 / 3600;

    const total50Val = hours50Decimal * hourlyRate * 1.5;
    const total100Val = hours100Decimal * hourlyRate * 2.0;
    const grandTotalVal = total50Val + total100Val;

    const formatTd = (sec: number) => {
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
    };

    return {
      evaluatedDays,
      total50Formatted: formatTd(totalSeconds50),
      total100Formatted: formatTd(totalSeconds100),
      total50Val,
      total100Val,
      grandTotalVal,
      discardedDaysCount,
      approvedDaysCount
    };
  }, [sampleDays, toleranceMinutes, includeExcessOnly, apply100Percent, hourlyRate]);

  // Handle copy python code
  const handleCopyCode = () => {
    const code = generatePythonCode(toleranceMinutes, startRow, includeExcessOnly, apply100Percent);
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download Python file
  const handleDownloadPy = () => {
    const code = generatePythonCode(toleranceMinutes, startRow, includeExcessOnly, apply100Percent);
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'calcular_extras_19min.py';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Download sample Excel template for testing
  const handleDownloadSampleExcel = () => {
    const wb = XLSX.utils.book_new();

    // Create Sheet for Employee "JOAO DA SILVA"
    // Row 1: Headers (U1: ExU50, V1: ExS100, W1: ExD100, X1: ExF100)
    const headerRow: string[] = new Array(24).fill('');
    headerRow[0] = 'Dia';
    headerRow[1] = 'Data';
    headerRow[20] = 'ExU50';  // Column U (index 20)
    headerRow[21] = 'ExS100'; // Column V (index 21)
    headerRow[22] = 'ExD100'; // Column W (index 22)
    headerRow[23] = 'ExF100'; // Column X (index 23)

    const rows: any[] = [headerRow];

    // Add days
    sampleDays.forEach((item, idx) => {
      const row = new Array(24).fill('');
      row[0] = `Dia ${item.day}`;
      row[1] = `2026-09-${(item.day).toString().padStart(2, '0')}`;
      row[20] = item.exU50; // U
      row[21] = item.ex100; // V
      row[22] = '00:00';    // W
      row[23] = '00:00';    // X
      rows.push(row);
    });

    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, "JOAO DA SILVA");

    // Add another employee
    const rows2: any[] = [headerRow];
    const daysMaria = [
      { day: 1, u: "00:18", v: "00:00" }, // <= 19 descartado
      { day: 2, u: "00:40", v: "00:00" }, // > 19 aceito
      { day: 3, u: "01:20", v: "02:00" }, // > 19 aceito
      { day: 4, u: "00:10", v: "00:00" }, // <= 19 descartado
    ];
    daysMaria.forEach(item => {
      const row = new Array(24).fill('');
      row[0] = `Dia ${item.day}`;
      row[1] = `2026-09-${(item.day).toString().padStart(2, '0')}`;
      row[20] = item.u;
      row[21] = item.v;
      row[22] = '00:00';
      row[23] = '00:00';
      rows2.push(row);
    });
    const ws2 = XLSX.utils.aoa_to_sheet(rows2);
    XLSX.utils.book_append_sheet(wb, ws2, "MARIA SANTOS");

    XLSX.writeFile(wb, "ponto_exemplo.xlsx");
  };

  // Download sample salarios.xlsx with 'excessão extra' tab
  const handleDownloadSalarios = () => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: Salarios (Valor Hora)
    const rowsSalarios = [
      ["Nome do Funcionário", "Valor Hora"],
      ["JOAO DA SILVA", 18.50],
      ["MARIA SANTOS", 22.00],
      ["CARLOS SOUZA (EXCEÇÃO)", 25.00]
    ];
    const ws1 = XLSX.utils.aoa_to_sheet(rowsSalarios);
    XLSX.utils.book_append_sheet(wb, ws1, "Salarios");

    // Sheet 2: Excessão Extra (A1:A)
    const rowsExcecao = [
      ["Nomes com cálculo de cada minuto"],
      ["CARLOS SOUZA (EXCEÇÃO)"]
    ];
    const ws2 = XLSX.utils.aoa_to_sheet(rowsExcecao);
    XLSX.utils.book_append_sheet(wb, ws2, "excessão extra");

    XLSX.writeFile(wb, "salarios.xlsx");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-20 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/20">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                Cálculo de Extras <span className="text-amber-400 font-semibold">• Regra de {toleranceMinutes} Minutos</span>
              </h1>
              <p className="text-xs text-slate-400">
                Ajuste do script Python para cálculo condicional de horas extras 50%
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700/60 overflow-x-auto">
            <button
              onClick={() => setActiveTab('explanation')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'explanation' 
                  ? 'bg-amber-500 text-slate-950 shadow font-semibold' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              1. Perguntas & Explicação
            </button>
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'simulator' 
                  ? 'bg-amber-500 text-slate-950 shadow font-semibold' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              2. Simulador Dia a Dia
            </button>
            <button
              onClick={() => setActiveTab('python')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'python' 
                  ? 'bg-amber-500 text-slate-950 shadow font-semibold' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              3. Código Python Completo
            </button>
            <button
              onClick={() => setActiveTab('tester')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'tester' 
                  ? 'bg-amber-500 text-slate-950 shadow font-semibold' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              4. Testar Arquivo Excel
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
        {/* Quick Summary Banner */}
        <div className="bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 border border-amber-500/30 rounded-2xl p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 mt-0.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-amber-300">
                  Entendido perfeitamente! Veja como a regra muda o seu script
                </h2>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  No seu script atual, ele lia <strong>apenas a célula U2</strong> (o total já somado da coluna).
                  Para filtrar apenas os dias em que o funcionário fez <strong>acima de {toleranceMinutes} minutos</strong>, o script agora percorre <strong>linha a linha (dia a dia)</strong>, descartando dias com ≤ {toleranceMinutes} min e somando apenas os dias válidos!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setActiveTab('python')}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 shadow-lg shadow-amber-500/20"
              >
                Ver Código Python <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* TAB 1: Explicação e Perguntas Cruciais */}
        {activeTab === 'explanation' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* O que mudou */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-2 text-amber-400 mb-4 font-semibold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  Diagnóstico do seu Script Atual vs. Novo Requisito
                </div>
                
                <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
                  <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-800/40 text-rose-200">
                    <strong className="text-rose-400 block mb-1">Como seu Python fazia antes:</strong>
                    Ele lia diretamente <code>ws['U2'].value</code>. Ou seja, ele presumia que na linha 2 já havia um somatório total do mês inteiro. Dessa forma, era impossível saber quanto o funcionário fez em cada dia individual.
                  </div>

                  <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-800/40 text-emerald-200">
                    <strong className="text-emerald-400 block mb-1">Como o novo Python faz agora:</strong>
                    Ele percorre cada linha de dia da planilha (ex: da linha 2 até o fim da aba). Para cada dia, analisa a coluna U:
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>Se no dia fez <strong>15 minutos</strong> (≤ 19 min) ➔ <strong>Desconsidera</strong> (0 min somados).</li>
                      <li>Se no dia fez <strong>19 minutos</strong> (≤ 19 min) ➔ <strong>Desconsidera</strong> (0 min somados).</li>
                      <li>Se no dia fez <strong>20 minutos ou mais</strong> (&gt; 19 min) ➔ <strong>Soma</strong> ao total do funcionário!</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Respostas Confirmadas da sua Planilha Real */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-2 text-emerald-400 mb-4 font-semibold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  Estrutura Confirmada da sua Planilha (PONTO 0109 A 23092026.xlsx)
                </div>

                <div className="space-y-3 text-xs text-slate-300">
                  <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-amber-300">1. Linha de Início dos Dias</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-mono font-bold">LINHA_INICIO_DIAS = 3</span>
                    </div>
                    <p className="text-slate-300">
                      Os dias começam na <strong>Linha 3</strong> (01/09/2026 Ter). A <strong>Linha 2</strong> é o resumo do sistema (<code>Totais &gt;&gt;&gt;</code>) e foi <strong>completamente ignorada</strong> para não duplicar o cálculo.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-amber-300">2. Modo de Acúmulo</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-mono font-bold">MODO_EXCEDENTE = False</span>
                    </div>
                    <p className="text-slate-300">
                      <strong>Integral (padrão CLT):</strong> Ao ultrapassar a carência de 19 minutos (ex: 20 min, 25 min, 1h), computa-se o tempo integral do dia, sem descontar os 19 minutos.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-amber-300">3. Extras 100% (V, W, X)</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-mono font-bold">APLICAR_REGRA_EM_100 = False</span>
                    </div>
                    <p className="text-slate-300">
                      A carência de 19 minutos é <strong>exclusiva para 50%</strong> (coluna U). As horas a 100% (ExS100, ExD100, ExF100) entram normais, sem carência.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-amber-300">4. Totalizador de Rodapé</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-mono font-bold">Filtro Preventivo Ativo</span>
                    </div>
                    <p className="text-slate-300">
                      Os dados vão direto até a linha 25 (dia 23/09/2026 Qua). Não há total no rodapé, apenas no topo (linha 2), que já está filtrado.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/50">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-purple-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                        5. Aba 'excessão extra' (salarios.xlsx)
                      </span>
                      <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px] font-mono font-bold">CADA MINUTO</span>
                    </div>
                    <p className="text-purple-200/90">
                      Os funcionários listados na coluna <strong>A1:A</strong> da aba <strong>excessão extra</strong> são calculados minuto a minuto (sem exigência dos 19 minutos mínimos).
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Parameter adjust card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 text-white font-semibold text-sm mb-4">
                <Settings className="w-5 h-5 text-amber-400" />
                Configurar Parâmetros da Regra (o código Python e o simulador se adaptam em tempo real):
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                {/* Minutos Carência */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <label className="text-slate-400 font-medium block mb-2">Tolerância Mínima Diária (minutos)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={toleranceMinutes} 
                      onChange={(e) => setToleranceMinutes(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-bold text-center focus:border-amber-500 focus:outline-none"
                    />
                    <span className="text-slate-400 font-semibold">min</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1.5">
                    Só soma o dia se for &gt; {toleranceMinutes} minutos (ex: a partir de {toleranceMinutes + 1}m).
                  </p>
                </div>

                {/* Linha inicial */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <label className="text-slate-400 font-medium block mb-2">Linha de Início dos Dias no Excel</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={startRow} 
                      onChange={(e) => setStartRow(Math.max(2, parseInt(e.target.value) || 2))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-bold text-center focus:border-amber-500 focus:outline-none"
                    />
                    <span className="text-slate-400 font-semibold">linha</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1.5">
                    Se cabeçalho for na linha 1, os dias começam na linha 2.
                  </p>
                </div>

                {/* Modo Integral vs Excedente */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <label className="text-slate-400 font-medium block mb-2">Quando ultrapassar {toleranceMinutes} min:</label>
                  <div className="space-y-1.5 pt-0.5">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="modo" 
                        checked={!includeExcessOnly} 
                        onChange={() => setIncludeExcessOnly(false)} 
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      <span className="text-slate-200">Soma Integral (ex: 25 min ➔ 25m)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="modo" 
                        checked={includeExcessOnly} 
                        onChange={() => setIncludeExcessOnly(true)} 
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      <span className="text-slate-200">Apenas Excedente (25 - {toleranceMinutes} = {Math.max(0, 25 - toleranceMinutes)}m)</span>
                    </label>
                  </div>
                </div>

                {/* 100% com ou sem carência */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <label className="text-slate-400 font-medium block mb-2">Regra para Horas 100% (V, W, X):</label>
                  <div className="space-y-1.5 pt-0.5">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="regra100" 
                        checked={!apply100Percent} 
                        onChange={() => setApply100Percent(false)} 
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      <span className="text-slate-200">Sem carência (soma tudo de 100%)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="regra100" 
                        checked={apply100Percent} 
                        onChange={() => setApply100Percent(true)} 
                        className="text-amber-500 focus:ring-amber-500"
                      />
                      <span className="text-slate-200">Aplicar {toleranceMinutes} min também em 100%</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Simulador Interativo */}
        {activeTab === 'simulator' && (
          <div className="space-y-6">
            {/* Header info */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Calculator className="w-5 h-5 text-amber-400" />
                    Simulação Prática Dia a Dia de um Colaborador
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Altere os minutos dos dias abaixo para ver quais são aceitos (&gt; {toleranceMinutes} min) e quais são descartados (≤ {toleranceMinutes} min).
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-xs bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    <span className="text-slate-400">Salário / Hora:</span>
                    <input 
                      type="number" 
                      step="0.5" 
                      value={hourlyRate}
                      onChange={(e) => setHourlyRate(parseFloat(e.target.value) || 0)}
                      className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-white font-bold text-right focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <button
                    onClick={handleDownloadSampleExcel}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
                    title="Baixar planilha de exemplo ponto_exemplo.xlsx"
                  >
                    <Download className="w-3.5 h-3.5 text-amber-400" />
                    Baixar Modelo XLSX
                  </button>
                </div>
              </div>

              {/* Table of days */}
              <div className="overflow-x-auto mt-4">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                      <th className="py-2.5 px-3">Dia</th>
                      <th className="py-2.5 px-3">Extras 50% (Coluna U)</th>
                      <th className="py-2.5 px-3">Status da Regra (&gt; {toleranceMinutes}m)</th>
                      <th className="py-2.5 px-3">Tempo Considerado</th>
                      <th className="py-2.5 px-3">Extras 100% (V/W/X)</th>
                      <th className="py-2.5 px-3 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {simulationResults.evaluatedDays.map((item, idx) => (
                      <tr key={item.day} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 px-3 font-medium text-slate-300">
                          Dia {item.day}
                        </td>
                        <td className="py-2.5 px-3">
                          <input 
                            type="text" 
                            value={item.exU50}
                            onChange={(e) => {
                              const newDays = [...sampleDays];
                              newDays[idx].exU50 = e.target.value;
                              setSampleDays(newDays);
                            }}
                            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-white font-mono w-24 focus:border-amber-500 focus:outline-none"
                            placeholder="HH:MM"
                          />
                        </td>
                        <td className="py-2.5 px-3">
                          {item.sec50 === 0 ? (
                            <span className="text-slate-500 italic">Sem extra</span>
                          ) : item.isApproved50 ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Aprovado (&gt; {toleranceMinutes} min)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-medium">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              Descartado (≤ {toleranceMinutes} min)
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-semibold">
                          {item.countedSec50 > 0 ? (
                            <span className="text-emerald-300">
                              {Math.floor(item.countedSec50 / 3600).toString().padStart(2, '0')}:
                              {Math.floor((item.countedSec50 % 3600) / 60).toString().padStart(2, '0')}
                            </span>
                          ) : (
                            <span className="text-slate-500">00:00</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3">
                          <input 
                            type="text" 
                            value={item.ex100}
                            onChange={(e) => {
                              const newDays = [...sampleDays];
                              newDays[idx].ex100 = e.target.value;
                              setSampleDays(newDays);
                            }}
                            className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-white font-mono w-24 focus:border-amber-500 focus:outline-none"
                            placeholder="HH:MM"
                          />
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={() => {
                              if (sampleDays.length > 1) {
                                setSampleDays(sampleDays.filter((_, i) => i !== idx));
                              }
                            }}
                            className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                            title="Remover dia"
                          >
                            ×
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Add day button */}
              <div className="mt-3 flex justify-between items-center">
                <button
                  onClick={() => {
                    const nextDay = (sampleDays[sampleDays.length - 1]?.day || 0) + 1;
                    setSampleDays([...sampleDays, { day: nextDay, exU50: "00:22", ex100: "00:00" }]);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
                >
                  + Adicionar Outro Dia
                </button>

                <div className="flex items-center gap-4 text-xs text-slate-400">
                  <span>Dias Considerados: <strong className="text-emerald-400">{simulationResults.approvedDaysCount}</strong></span>
                  <span>Dias Descartados: <strong className="text-rose-400">{simulationResults.discardedDaysCount}</strong></span>
                </div>
              </div>
            </div>

            {/* Total Results Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Card 50% */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
                <div className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>Extras 50% Consideradas</span>
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px]">
                    fator 1.5x
                  </span>
                </div>
                <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                  {simulationResults.total50Formatted} h
                </div>
                <div className="text-sm font-semibold text-slate-200 mt-2">
                  R$ {simulationResults.total50Val.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  {simulationResults.discardedDaysCount} dia(s) com ≤ {toleranceMinutes} min foram ignorados
                </div>
              </div>

              {/* Card 100% */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
                <div className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>Extras 100%</span>
                  <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[10px]">
                    fator 2.0x
                  </span>
                </div>
                <div className="text-2xl font-black text-blue-400 font-mono mt-1">
                  {simulationResults.total100Formatted} h
                </div>
                <div className="text-sm font-semibold text-slate-200 mt-2">
                  R$ {simulationResults.total100Val.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Colunas V (ExS100), W (ExD100) e X (ExF100)
                </div>
              </div>

              {/* Card Total Geral */}
              <div className="bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-5 shadow-sm">
                <div className="text-xs text-emerald-400 font-semibold uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>Total Final a Pagar</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-emerald-400 mt-1 font-mono">
                  R$ {simulationResults.grandTotalVal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className="text-xs text-slate-300 mt-2">
                  50% (R$ {simulationResults.total50Val.toFixed(2)}) + 100% (R$ {simulationResults.total100Val.toFixed(2)})
                </div>
                <div className="text-[11px] text-emerald-300/80 mt-1">
                  Baseado no valor-hora de R$ {hourlyRate.toFixed(2)}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Script Python Atualizado */}
        {activeTab === 'python' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 p-4 rounded-2xl border border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-amber-400" />
                  Script Python Completo com a Regra dos {toleranceMinutes} Minutos
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Substitua o conteúdo do seu script existente por este código.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-2 transition-all active:scale-95"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                  {copied ? 'Código Copiado!' : 'Copiar Código'}
                </button>

                <button
                  onClick={handleDownloadPy}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-amber-500/20 active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  Baixar .py
                </button>
              </div>
            </div>

            {/* Code Box */}
            <div className="relative rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
              <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 text-xs text-slate-400 font-mono">
                <span>relatorio_extras_19min.py</span>
                <span className="text-[11px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  openpyxl + pandas
                </span>
              </div>
              
              <pre className="p-5 text-xs text-slate-300 font-mono overflow-x-auto leading-relaxed max-h-[580px] overflow-y-auto">
                <code>{generatePythonCode(toleranceMinutes, startRow, includeExcessOnly, apply100Percent)}</code>
              </pre>
            </div>
          </div>
        )}

        {/* TAB 4: Testar Arquivo Excel */}
        {activeTab === 'tester' && (
          <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Upload className="w-5 h-5 text-amber-400" />
                      Testar Arquivo de Ponto Diretamente no Navegador
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Carregue o seu arquivo <strong>ponto.xlsx</strong> para ver o cálculo executado imediatamente com a regra de {toleranceMinutes} minutos!
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleDownloadSampleExcel}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-400" />
                      Baixar Ponto Exemplo
                    </button>
                    <button
                      onClick={handleDownloadSalarios}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-400" />
                      Baixar Salários Exemplo
                    </button>
                  </div>
                </div>

                {/* Upload Inputs */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
                  {/* File 1: Ponto */}
                  <div className="p-4 rounded-xl border-2 border-dashed border-slate-700 bg-slate-950 hover:border-amber-500/60 transition-colors flex flex-col items-center justify-center text-center">
                    <input 
                      type="file" 
                      accept=".xlsx, .xls"
                      id="upload-ponto"
                      className="hidden"
                      onChange={handlePontoFileUpload}
                    />
                    <label htmlFor="upload-ponto" className="cursor-pointer flex flex-col items-center p-3 w-full">
                      <div className="p-3 rounded-full bg-amber-500/10 text-amber-400 mb-2">
                        <Upload className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-bold text-white">
                        {pontoFileName || "Selecionar Arquivo de PONTO (.xlsx)"}
                      </span>
                      <span className="text-[11px] text-slate-400 mt-1">
                        {pontoFileName ? "Clique para trocar" : "Deve conter as abas dos funcionários com colunas U, V, W, X"}
                      </span>
                    </label>
                  </div>

                  {/* File 2: Salarios */}
                  <div className="p-4 rounded-xl border-2 border-dashed border-slate-700 bg-slate-950 hover:border-emerald-500/60 transition-colors flex flex-col items-center justify-center text-center">
                    <input 
                      type="file" 
                      accept=".xlsx, .xls"
                      id="upload-salarios"
                      className="hidden"
                      onChange={handleSalariosFileUpload}
                    />
                    <label htmlFor="upload-salarios" className="cursor-pointer flex flex-col items-center p-3 w-full">
                      <div className="p-3 rounded-full bg-emerald-500/10 text-emerald-400 mb-2">
                        <DollarSign className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-bold text-white">
                        {salariosFileName || "Selecionar Arquivo de SALÁRIOS (opcional)"}
                      </span>
                      <span className="text-[11px] text-slate-400 mt-1">
                        {salariosFileName 
                          ? `${salariosFileName} (${excecoesList.length} exceção(ões) na aba 'excessão extra')` 
                          : "Opcional. Contém valor-hora e aba 'excessão extra' para calcular cada minuto"}
                      </span>
                    </label>
                  </div>
                </div>

                {/* Exceções extra banner & management */}
                <div className="mt-4 p-4 rounded-xl bg-purple-950/40 border border-purple-800/50 text-purple-200 text-xs space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
                      <span className="font-bold text-purple-300">
                        Funcionários em Exceção (Identificação por Nome Completo):
                      </span>
                    </div>
                    <span className="text-[11px] text-purple-400/80 font-mono">
                      {excecoesList.length} cadastrado(s)
                    </span>
                  </div>

                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Identificação estrita por <strong>Nome Completo</strong> para evitar falsos positivos com outros funcionários. Colaboradores na lista <strong>NÃO</strong> sofrem carência de {toleranceMinutes} min — cada minuto a 50% ou 100% é somado integralmente e nenhum dia é descartado.
                  </p>

                  {/* Chips of registered exceptions */}
                  <div className="flex flex-wrap gap-1.5 items-center">
                    {excecoesList.length === 0 ? (
                      <span className="text-slate-500 italic text-xs">Nenhum funcionário na lista de exceção (carregue o salarios.xlsx com a aba de exceções ou adicione abaixo).</span>
                    ) : (
                      excecoesList.map((exc, idx) => (
                        <span 
                          key={idx} 
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-200 font-mono text-xs border border-purple-500/30 shadow-sm"
                        >
                          <Check className="w-3 h-3 text-purple-400" />
                          {exc}
                          <button
                            type="button"
                            onClick={() => {
                              const updated = excecoesList.filter((_, i) => i !== idx);
                              setExcecoesList(updated);
                              setProcessedResults(prev => recalculateAllResults(prev, updated, toleranceMinutes, includeExcessOnly, apply100Percent, salariosMap));
                            }}
                            className="hover:text-rose-400 transition-colors p-0.5"
                            title="Remover exceção"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))
                    )}
                  </div>

                  {/* Manual add input */}
                  <div className="flex items-center gap-2 pt-2 border-t border-purple-900/40">
                    <input 
                      type="text"
                      value={newExcecaoInput}
                      onChange={(e) => setNewExcecaoInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const val = newExcecaoInput.trim().toUpperCase();
                          if (val && !excecoesList.includes(val)) {
                            const updated = [...excecoesList, val];
                            setExcecoesList(updated);
                            setNewExcecaoInput('');
                            setProcessedResults(prev => recalculateAllResults(prev, updated, toleranceMinutes, includeExcessOnly, apply100Percent, salariosMap));
                          }
                        }
                      }}
                      placeholder="Adicionar nome completo manualmente (ex: IVANILTON PEREIRA DA SILVA)..."
                      className="flex-1 bg-slate-950 border border-purple-800/60 rounded-lg px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-400"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const val = newExcecaoInput.trim().toUpperCase();
                        if (val && !excecoesList.includes(val)) {
                          const updated = [...excecoesList, val];
                          setExcecoesList(updated);
                          setNewExcecaoInput('');
                          setProcessedResults(prev => recalculateAllResults(prev, updated, toleranceMinutes, includeExcessOnly, apply100Percent, salariosMap));
                        }
                      }}
                      className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Adicionar Exceção
                    </button>
                  </div>
                </div>

                {uploadError && (
                  <div className="mt-4 p-3.5 rounded-xl bg-rose-950/40 border border-rose-800/50 text-rose-300 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{uploadError}</span>
                  </div>
                )}
              </div>

              {/* Uploaded Results Table */}
              {processedResults.length > 0 && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        Resultado do Processamento das Abas ({processedResults.length} funcionários)
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Regra Geral: dias com extras 50% ≤ {toleranceMinutes} min descartados. Exceções: cada minuto calculado.
                      </p>
                    </div>

                    <button
                      onClick={handleExportCalculatedExcel}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors shadow-lg shadow-emerald-600/20"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Exportar EXTRAS CALCULADAS.xlsx
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                          <th className="py-2.5 px-3">Funcionário (Auditoria)</th>
                          <th className="py-2.5 px-3">Regra</th>
                          <th className="py-2.5 px-3">Extras 50%</th>
                          <th className="py-2.5 px-3">Total 50% (R$)</th>
                          <th className="py-2.5 px-3">Extras 100%</th>
                          <th className="py-2.5 px-3">Total 100% (R$)</th>
                          <th className="py-2.5 px-3">Total Geral</th>
                          <th className="py-2.5 px-3 text-center">Dias Aprovados</th>
                          <th className="py-2.5 px-3 text-center">Dias Descartados</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-mono">
                        {processedResults.map((r, i) => (
                          <tr 
                            key={i} 
                            onClick={() => setSelectedEmployeeDetail(r)}
                            className="hover:bg-slate-800/50 cursor-pointer transition-colors group"
                            title="Clique para abrir auditoria dia a dia deste funcionário"
                          >
                            <td className="py-2.5 px-3 font-sans font-semibold text-slate-200">
                              <div className="flex items-center gap-2">
                                <span className="group-hover:text-amber-400 transition-colors">{r.nome}</span>
                                <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 group-hover:bg-indigo-500/40">
                                  <Eye className="w-3 h-3" /> Ver Dias
                                </span>
                              </div>
                            </td>
                            <td className="py-2.5 px-3 font-sans">
                              {r.ehExcecao ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                                  Exceção (Cada Minuto)
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                                  Geral (&gt; {toleranceMinutes}m)
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-amber-400 font-bold">{r.extras50}</td>
                            <td className="py-2.5 px-3 text-slate-200">
                              R$ {r.total50.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2.5 px-3 text-blue-400 font-bold">{r.extras100}</td>
                            <td className="py-2.5 px-3 text-slate-200">
                              R$ {r.total100.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2.5 px-3 text-emerald-400 font-bold">
                              R$ {r.totalGeral.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-2.5 px-3 text-center text-emerald-400 font-sans">
                              {r.diasAprovados}
                            </td>
                            <td className="py-2.5 px-3 text-center font-sans">
                              {r.diasDescartados > 0 ? (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedEmployeeDetail(r);
                                  }}
                                  className="inline-flex items-center gap-1 font-bold text-rose-300 bg-rose-500/20 hover:bg-rose-500/30 px-2.5 py-1 rounded-md border border-rose-500/40 text-xs shadow-sm transition-all"
                                  title="Clique para ver o dia descartado"
                                >
                                  <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                                  {r.diasDescartados} descartado{r.diasDescartados > 1 ? 's' : ''} (Ver)
                                </button>
                              ) : (
                                <span className="text-slate-500">0</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Modal de Detalhamento Diário do Funcionário */}
              {selectedEmployeeDetail && (
                <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
                  <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
                    {/* Header do Modal */}
                    <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-bold text-white">
                            {selectedEmployeeDetail.nome}
                          </h3>
                          {selectedEmployeeDetail.ehExcecao ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              Exceção (Cada Minuto)
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                              Regra Geral (&gt; {toleranceMinutes} min)
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          Auditoria de cada dia trabalhado • Extras 50% (ExU50) e 100% (ExS100, ExD100, ExF100)
                        </p>
                      </div>
                      <button
                        onClick={() => setSelectedEmployeeDetail(null)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                      >
                        ✕
                      </button>
                    </div>

                    {/* Resumo Rápido */}
                    <div className="grid grid-cols-4 gap-2 p-4 bg-slate-950/60 border-b border-slate-800/80 text-center text-xs">
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Total 50%</span>
                        <span className="font-bold text-amber-400 font-mono text-sm">{selectedEmployeeDetail.extras50}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Total 100%</span>
                        <span className="font-bold text-blue-400 font-mono text-sm">{selectedEmployeeDetail.extras100}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Dias Aprovados 50%</span>
                        <span className="font-bold text-emerald-400 font-mono text-sm">{selectedEmployeeDetail.diasAprovados}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Dias Descartados 50%</span>
                        <span className={`font-bold font-mono text-sm ${selectedEmployeeDetail.diasDescartados > 0 ? 'text-rose-400' : 'text-slate-400'}`}>
                          {selectedEmployeeDetail.diasDescartados}
                        </span>
                      </div>
                    </div>

                    {/* Lista dos Dias */}
                    <div className="p-4 overflow-y-auto flex-1 space-y-2">
                      {selectedEmployeeDetail.diasDescartados > 0 && (
                        <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800/40 text-rose-200 text-xs flex items-start gap-2 mb-3">
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-bold block text-rose-300">
                              Por que houve {selectedEmployeeDetail.diasDescartados} dia(s) descartado(s)?
                            </span>
                            <span>
                              Na regra geral, a CLT e acordos de tolerância determinam que dias com <strong>≤ {toleranceMinutes} minutos</strong> de extra 50% (coluna ExU50) não são computados para pagamento. Veja abaixo exatamente qual dia teve minutos abaixo do limite:
                            </span>
                          </div>
                        </div>
                      )}

                      <table className="w-full text-xs text-left">
                        <thead>
                          <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                            <th className="py-2 px-2.5">Linha / Dia</th>
                            <th className="py-2 px-2.5">Data / Ref</th>
                            <th className="py-2 px-2.5">Extra 50% (ExU50)</th>
                            <th className="py-2 px-2.5">Extra 100%</th>
                            <th className="py-2 px-2.5">Status 50%</th>
                            <th className="py-2 px-2.5">Motivo / Explicação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                          {selectedEmployeeDetail.detalhesDias?.map((dia: any, idx: number) => {
                            const isDescartado = dia.status50 === 'descartado';
                            const isAprovado = dia.status50 === 'aprovado';
                            return (
                              <tr 
                                key={idx} 
                                className={isDescartado ? 'bg-rose-950/20 font-semibold' : 'hover:bg-slate-800/20'}
                              >
                                <td className="py-2 px-2.5 font-sans text-slate-300">
                                  {dia.labelDia} <span className="text-[10px] text-slate-500 font-mono">({dia.linha})</span>
                                </td>
                                <td className="py-2 px-2.5 font-sans text-slate-400">
                                  {dia.data || '-'}
                                </td>
                                <td className={`py-2 px-2.5 font-bold ${isDescartado ? 'text-rose-400' : isAprovado ? 'text-amber-400' : 'text-slate-500'}`}>
                                  {dia.exU50Str}
                                </td>
                                <td className="py-2 px-2.5 text-blue-400">
                                  {dia.ex100Str}
                                </td>
                                <td className="py-2 px-2.5 font-sans">
                                  {isAprovado && (
                                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                                      Aprovado
                                    </span>
                                  )}
                                  {isDescartado && (
                                    <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold border border-rose-500/30">
                                      Descartado (&le; {toleranceMinutes}m)
                                    </span>
                                  )}
                                  {dia.status50 === 'zerado' && (
                                    <span className="text-slate-600 text-[11px]">-</span>
                                  )}
                                </td>
                                <td className="py-2 px-2.5 font-sans text-slate-400 text-[11px]">
                                  {dia.motivo}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {/* Rodapé do Modal */}
                    <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
                      <span>
                        Dica: Caso <strong>{selectedEmployeeDetail.nome}</strong> deva receber cada minuto sem tolerância de {toleranceMinutes}m, adicione o nome dele na aba <strong>excessão extra</strong> do arquivo <strong>salarios.xlsx</strong>.
                      </span>
                      <button
                        onClick={() => setSelectedEmployeeDetail(null)}
                        className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors"
                      >
                        Fechar
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        Calculadora de Horas Extras e Processador de Ponto • Regra de {toleranceMinutes} Minutos (CLT / Acordo)
      </footer>
    </div>
  );
}
